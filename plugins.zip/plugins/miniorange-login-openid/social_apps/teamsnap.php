<?php


class mo_teamsnap
{
    public $color="#FF6C0B";
}