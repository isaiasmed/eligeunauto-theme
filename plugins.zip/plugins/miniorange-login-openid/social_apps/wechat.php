<?php


class mo_wechat
{
    public $color="#2DC100";
}