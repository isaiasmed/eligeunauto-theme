<?php


class mo_fitbit
{
    public $color="#373B41";

}