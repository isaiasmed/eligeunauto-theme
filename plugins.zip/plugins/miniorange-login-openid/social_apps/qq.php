<?php


class mo_qq
{
    public $color="#009CC1";
}