<?php


class mo_mailchimp
{
    public $color="#FFE01B";

}