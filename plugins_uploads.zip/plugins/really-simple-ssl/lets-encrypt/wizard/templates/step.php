<div class="rsssl-step">
    <div class="rsssl-step-header {active} {completed}">
        <a href="{url}">
            <h2>{title}</h2>
        </a>
    </div>
    {sections}
</div>
