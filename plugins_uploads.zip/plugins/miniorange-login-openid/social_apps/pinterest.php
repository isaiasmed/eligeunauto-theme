<?php


class mo_pinterest
{
    public $color="#D73532";
}