<?php


class mo_stackoverflow
{
    public $color="#D93E06";

}