<?php


class mo_paypal
{
    public $color = "#039BE5";

}