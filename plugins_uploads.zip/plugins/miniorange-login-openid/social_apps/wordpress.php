<?php


class mo_wordpress
{
    public $color="#346DA6";
}