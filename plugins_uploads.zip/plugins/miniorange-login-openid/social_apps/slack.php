<?php


class mo_slack
{
    public $color="#4A154B";
}