<?php


class mo_yandex
{
    public $color="#E52620";
}