<?php


class mo_strava
{
    public $color="#FC4C02";
}