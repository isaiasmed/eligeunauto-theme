<?php


class mo_youtube
{
    public $color="#D93E06";

}