<?php


class mo_tumblr
{
    public $color="#34465D";
}