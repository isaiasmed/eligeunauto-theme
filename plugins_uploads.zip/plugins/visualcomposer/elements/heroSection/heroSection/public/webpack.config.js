module.exports = {
  entry: {
    heroSection: ['./js/heroSection.js']
  },
  output: {
    filename: 'dist/[name].min.js'
  }
}
